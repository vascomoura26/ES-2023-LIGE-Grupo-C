let table;

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('csvFileInput').addEventListener('change', handleFileSelect, false);
});

function handleFileSelect(event) {
    const file = event.target.files[0];
    parseFile(file);
}

function parseFile(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const data = parseCSV(contents);
        createTable(data.headers, data.data);
        createColumnControls(data.headers);
    };
    reader.readAsText(file);
}

// Adicionada função para gerar o CSV das colunas visíveis

/* metes esta função no salas.js */
function exportTabulatorToCSV() {
    var headers = table.getColumns().filter(column => column.isVisible()).map(column => column.getDefinition().title);
    var csvContent = [headers.join(',')];

    table.getData().forEach(row => {
        var rowData = headers.map(header => row[header]);
        csvContent.push(rowData.join(','));
    });

    return csvContent.join('\n');
}

/* metes esta função no salas.js */

function uploadFile() {
    var updatedCSV = exportTabulatorToCSV();
    var blob = new Blob([updatedCSV], { type: 'text/csv;charset=utf-8;' });

    var formData = new FormData();
    formData.append('file', blob, 'HorarioDeExemploAtualizado.csv');
    //aqui vais ter de mudar de upload para upload horario e no salas.js mudas para upload-salas
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if(response.ok) {
            return response.text();
        }
        throw new Error('Falha ao salvar o arquivo.');
    })
    .then(text => console.log(text))
    .catch(error => console.error(error));
}

// Outras funções permanecem inalteradas...



function parseCSV(csvData) {
    const rows = csvData.trim().split('\n').map(row => row.split(';').map(field => field.trim()));
    const headers = rows.shift(); // Remove a primeira linha e considera-a como cabeçalhos
    headers.push('Semana do Ano', 'Semana do 1º Semestre', 'Semana do 2º Semestre'); // Adiciona os novos cabeçalhos

    const data = rows.map(row => {
        const obj = {};
        headers.forEach((header, index) => {
            if (index < row.length) {
                obj[header] = row[index];
            }
        });

        // Aqui você adicionaria o cálculo das semanas baseado na 'Data da aula'
        const dateOfAula = obj['Data da aula']; // Certifique-se que a coluna 'Data da aula' existe
        if(dateOfAula) {
            obj['Semana do Ano'] = calculateWeekOfYear(dateOfAula);
            obj['Semana do 1º Semestre'] = calculateSemesterWeek(dateOfAula, '2022-10-01', 1);
            obj['Semana do 2º Semestre'] = calculateSemesterWeek(dateOfAula, '2023-02-01', 2);
        }

        return obj;
    });
    return { headers, data };
}

function calculateWeekOfYear(dateStr) {
    const date = new Date(dateStr.split('/').reverse().join('-'));
    const start = new Date(date.getFullYear(), 0, 1);
    // Ajuste para garantir que a semana comece em 1
    const weekNo = Math.ceil(((date - start) / (24 * 60 * 60 * 1000) + start.getDay() + 1) / 7);
    return Math.max(weekNo, 1); // Garante que o mínimo retornado seja 1
}

function calculateSemesterWeek(dateStr, semesterStartStr, semesterNumber) {
    const date = new Date(dateStr.split('/').reverse().join('-'));
    const semesterStart = new Date(semesterStartStr);
    const oneWeek = 1000 * 60 * 60 * 24 * 7;
    
    // Ajustando para não permitir semanas fora do intervalo de 1 a 15
    let weekNo = Math.floor((date - semesterStart) / oneWeek) + 1;

    // Retorna "-" se a semana não estiver dentro do intervalo permitido
    if (weekNo < 1 || weekNo > 15) {
        return "-";
    }

    return weekNo;
}

function createTable(headers, data) {
    // Define as colunas com base nos cabeçalhos do CSV
    const columns = headers.map(header => ({ 
        title: header, 
        field: header,
        headerFilter: 'input'
    }));

    // Cria a tabela
    table = new Tabulator("#tableContainer", {
        data: data,
        columns: columns,
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: headers[0], dir: "asc" }]
    });

    // Após criar a tabela, cria os controles de coluna
    createColumnControls(headers);
}

function createColumnControls(headers) {
    const controlsContainer = document.getElementById('column-controls');
    controlsContainer.innerHTML = ''; // Limpa os controles existentes

    headers.forEach(header => {
        const button = document.createElement('button');
        button.textContent = header;
        button.setAttribute('data-column', header); // Atributo para identificar a coluna
        button.onclick = function() {
            toggleColumn(header);
        };
        controlsContainer.appendChild(button);
    });
}


function toggleColumn(column) {
    const col = table.getColumn(column);
    col.toggle(); // Alterna a visibilidade da coluna

    // Encontra o botão correspondente à coluna e alterna a classe
    const button = document.querySelector(`#column-controls button[data-column='${column}']`);
    if (button) {
        // Se a coluna agora está invisível, adiciona a classe para alterar a cor do botão
        if (!col.isVisible()) {
            button.classList.add('button-inactive');
        } else {
            button.classList.remove('button-inactive');
        }
    }
}
// Função de filtro "OU"
function orFilterFunction(data, filterParams){
    // Itera por cada chave (coluna) no objeto de parâmetros do filtro
    for (let key of Object.keys(filterParams)) {
        // Se algum valor da linha (data[key]) corresponder ao valor de pesquisa (filterParams[key]),
        // retorna verdadeiro para incluir esta linha nos resultados do filtro
        if (data[key] && data[key].toString().toLowerCase().includes(filterParams[key].toLowerCase())) {
            return true; // A linha deve ser incluída se qualquer condição "OU" for verdadeira
        }
    }
    // Se nenhum valor corresponder, retorna falso para excluir esta linha dos resultados do filtro
    return false;
}

// Função para aplicar o filtro "OU" baseado no valor inserido na barra de pesquisa
function applyOrFilter(){
    const searchValue = document.getElementById('or-search-input').value.trim();
    if (searchValue) {
        // Define os parâmetros do filtro com base nos campos que você quer incluir na pesquisa "OU"
        // Neste exemplo, estamos apenas passando um objeto com um valor de pesquisa genérico que será verificado contra todas as colunas
        // Para um caso mais específico, você pode ajustar os parâmetros para se adequarem às suas colunas específicas
        const filterParams = {};
        table.getColumns().forEach(column => {
            filterParams[column.getField()] = searchValue;
        });
        
        table.setFilter(orFilterFunction, filterParams);
    } else {
        table.clearFilter(); // Limpa o filtro se o campo de pesquisa estiver vazio
    }
}



