package model;

import org.springframework.data.jpa.repository.JpaRepository;
import model.Sala;

public interface SalaRepository extends JpaRepository<Sala, Integer> {
    // Aqui você pode adicionar consultas personalizadas, se necessário
}

