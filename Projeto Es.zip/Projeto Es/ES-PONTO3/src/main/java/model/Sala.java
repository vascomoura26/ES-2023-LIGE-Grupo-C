package model;

import javax.persistence.*;

@Entity
@Table(name = "salas")
public class Sala {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "edificio")
    private String edificio;

    @Column(name = "nome_sala")
    private String nomeSala;

    @Column(name = "capacidade_normal")
    private Integer capacidadeNormal;

    @Column(name = "capacidade_exame")
    private Integer capacidadeExame;

    @Column(name = "numero_caracteristicas")
    private Integer numeroCaracteristicas;

    // Outros campos como Laboratórios, Arquivos, etc.
    // Dependendo do tipo de dados, você pode usar String ou uma Collection.
    // Aqui estou assumindo Strings simples para fins de exemplo.

    @Column(name = "laboratorios")
    private String laboratorios;

    @Column(name = "arquivos")
    private String arquivos;

    @Column(name = "anfiteatro_aulas")
    private Boolean anfiteatroAulas;

    @Column(name = "apoio_tecnico_eventos")
    private Boolean apoioTecnicoEventos;

    @Column(name = "byod")
    private Boolean byod; // BYOD (Bring Your Own Device)

    @Column(name = "focus_group")
    private Boolean focusGroup;

    @Column(name = "horario_sala_visivel_portal_publico")
    private Boolean horarioSalaVisivelPortalPublico;

    @Column(name = "sala_aulas_mestrado")
    private Boolean salaAulasMestrado;

    @Column(name = "sala_aulas_mestrado_plus")
    private Boolean salaAulasMestradoPlus;

    @Column(name = "sala_nee")
    private Boolean salaNee;

    @Column(name = "sala_provas")
    private Boolean salaProvas;

    @Column(name = "sala_reuniao")
    private Boolean salaReuniao;

    @Column(name = "sala_de_arquitectura")
    private Boolean salaDeArquitectura;

    @Column(name = "sala_de_aulas_normal")
    private Boolean salaDeAulasNormal;

    @Column(name = "videoconferencia")
    private Boolean videoconferencia;

    @Column(name = "atrio")
    private Boolean atrio;

    // Getters e setters
    // Aqui estão os getters e setters para apenas alguns dos campos como exemplo.
    // Você precisará gerar o resto usando sua IDE ou manualmente.

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEdificio() {
        return edificio;
    }

    public void setEdificio(String edificio) {
        this.edificio = edificio;
    }

    public String getNomeSala() {
        return nomeSala;
    }

    public void setNomeSala(String nomeSala) {
        this.nomeSala = nomeSala;
    }

    public Integer getCapacidadeNormal() {
        return capacidadeNormal;
    }

    public void setCapacidadeNormal(Integer capacidadeNormal) {
        this.capacidadeNormal = capacidadeNormal;
    }

    // Continue adicionando getters e setters para os outros campos...
}
