package model;

import java.util.List;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/salas")
public class SalaController {

    @Autowired
    private SalaService salaService;

    @GetMapping
    public ResponseEntity<List<Sala>> getAllSalas() {
        return ResponseEntity.ok(salaService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Sala> getSalaById(@PathVariable Integer id) {
        return salaService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Sala> createSala(@RequestBody Sala sala) {
        return ResponseEntity.ok(salaService.save(sala));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSala(@PathVariable Integer id) {
        salaService.delete(id);
        return ResponseEntity.ok().build();
    }
    @PutMapping("/{id}")
public ResponseEntity<Sala> updateSala(@PathVariable Integer id, @RequestBody Sala salaDetalhes) {
    return (ResponseEntity<Sala>) salaService.findById(id).map(salaExistente -> {
                // Atualize os campos da sala existente com salaDetalhes
                salaExistente.setEdificio(salaDetalhes.getEdificio());
                salaExistente.setNomeSala(salaDetalhes.getNomeSala());
                // Continue com todos os campos necessários
                Sala atualizada = salaService.save(salaExistente);
                return new ResponseEntity<>(atualizada, HttpStatus.OK);
            })
            .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
}
@PostMapping("/upload")
public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) {
    if (file.isEmpty()) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Arquivo vazio não pode ser carregado");
    }
    try {
        // O serviço processa o arquivo e atualiza o banco de dados
        salaService.processSalasFile(file);
        return ResponseEntity.ok("Arquivo processado com sucesso!");
    } catch (Exception e) {
        e.printStackTrace();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Falha ao processar o arquivo");
    }
}
    // Adicionar outros endpoints conforme necessário
}

