package model;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class SalaService {

    @Autowired
    private SalaRepository salaRepository;

    public List<Sala> findAll() {
        return salaRepository.findAll();
    }

    public Optional<Sala> findById(Integer id) {
        return salaRepository.findById(id);
    }

    public Sala save(Sala sala) {
        return salaRepository.save(sala);
    }

    public void delete(Integer id) {
        salaRepository.deleteById(id);
    }

    // Outros métodos conforme necessário
    public ResponseEntity<String> processHorariosFile(MultipartFile file) {
        // Lógica para processar o arquivo de horários e salvar no banco de dados
        // ...
    }

    public ResponseEntity<String> processSalasFile(MultipartFile file) {
        // Lógica para processar o arquivo de salas e salvar no banco de dados
        // ...
    }

    public boolean isSalaAvailable(String nomeSala, String dia, String horaInicio) {
        // Verificar no banco de dados se a sala está disponível
        // ...
    }
}

