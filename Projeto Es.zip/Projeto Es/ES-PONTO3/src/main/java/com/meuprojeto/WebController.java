package com.meuprojeto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import model.*;

@Controller
public class WebController {

    @Autowired
    private SalaService salaService;

    @GetMapping("/")
    public String viewHome() {
        return "hub";
    }

    @GetMapping("/horarios")
    public String viewHorarios() {
        return "horarios";
    }

    @GetMapping("/salas")
    public String viewSalas() {
        return "salas";
    }

    @PostMapping("/upload-horarios")
    public ResponseEntity<String> handleHorariosUpload(@RequestParam("file") MultipartFile file) {
        if (!file.isEmpty()) {
            // Processar o arquivo Excel e salvar no banco de dados
            // O processamento real será feito em um serviço dedicado
            return salaService.processHorariosFile(file);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Arquivo vazio não pode ser carregado");
        }
    }

    @PostMapping("/upload-salas")
    public ResponseEntity<String> handleSalasUpload(@RequestParam("file") MultipartFile file) {
        if (!file.isEmpty()) {
            // Processar o arquivo Excel e salvar no banco de dados
            // O processamento real será feito em um serviço dedicado
            return salaService.processSalasFile(file);
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Arquivo vazio não pode ser carregado");
        }
    }

    @GetMapping("/check-schedule")
    public ResponseEntity<String> checkSchedule(@RequestParam String nomeSala,
                                                @RequestParam String dia,
                                                @RequestParam String horaInicio) {
        boolean isAvailable = salaService.isSalaAvailable(nomeSala, dia, horaInicio);
        if (isAvailable) {
            return ResponseEntity.ok("DISPONIVEL");
        } else {
            return ResponseEntity.ok("OCUPADA");
        }
    }
}
